#!/usr/bin/env python3
"""
Feedback Synthesizer
---------------------
Turns raw, messy performance notes (peer comments, 360 feedback, self-assessments,
manager observations) into a concise, natural-sounding performance review: a
rating plus a short narrative grounded in specific, named examples.

This is a personal/portfolio tool with no ties to any employer's internal
systems, data, or prompts. Bring your own notes; nothing is stored or sent
anywhere except to the Anthropic API for generation.

Usage:
    export ANTHROPIC_API_KEY="sk-ant-..."
    python feedback_synthesizer.py --input notes.txt --employee "Alex Rivera" --language en

    # or pipe notes in directly
    cat notes.txt | python feedback_synthesizer.py --employee "Alex Rivera"
"""

import argparse
import sys
import os

SYSTEM_PROMPT = """You are an experienced people manager helping a colleague turn raw, unstructured \
feedback notes into a clear, fair, and well-written performance review.

Rules you must follow:
1. Ground every claim in a SPECIFIC, concrete example drawn from the notes provided. \
Never write generic praise or criticism ("great team player", "needs to improve communication") \
without tying it to an actual situation, behavior, and impact (the SBI model).
2. Preserve the manager's voice. Do not sound like a template. Vary sentence structure. \
Write like a thoughtful person, not a corporate form.
3. Be balanced. If the notes only contain positive comments, do not invent weaknesses — \
but do look for genuine, constructive growth areas if the notes support them. Never fabricate \
a criticism just to seem "balanced."
4. Keep it concise: a short narrative (roughly 120-220 words) plus a one-line summary rating \
(e.g. "Exceeds expectations", "Meets expectations", "Developing", "Needs improvement") \
with a one-sentence justification for that rating.
5. Match the language of the input notes (English or Spanish) unless the user specifies otherwise.
6. Do not include any information not present in or reasonably inferable from the notes. \
If the notes are too thin to support a claim, leave it out rather than padding with filler.

Output format:
## Rating
<rating> — <one-sentence justification>

## Narrative
<the review narrative, grounded in specific examples>
"""

USER_PROMPT_TEMPLATE = """Here are the raw notes about {employee}:

---
{notes}
---

Synthesize these into a performance review following the system instructions."""


def build_user_prompt(employee: str, notes: str) -> str:
    return USER_PROMPT_TEMPLATE.format(employee=employee, notes=notes.strip())


def call_anthropic(system_prompt: str, user_prompt: str, model: str) -> str:
    try:
        import anthropic
    except ImportError:
        sys.exit(
            "Missing dependency: run `pip install anthropic` first "
            "(see requirements.txt)."
        )

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        sys.exit(
            "Missing ANTHROPIC_API_KEY environment variable. "
            "Set it with: export ANTHROPIC_API_KEY=\"sk-ant-...\""
        )

    client = anthropic.Anthropic(api_key=api_key)
    response = client.messages.create(
        model=model,
        max_tokens=800,
        system=system_prompt,
        messages=[{"role": "user", "content": user_prompt}],
    )
    return "".join(block.text for block in response.content if block.type == "text")


def main():
    parser = argparse.ArgumentParser(description="Synthesize raw feedback notes into a performance review.")
    parser.add_argument("--input", "-i", help="Path to a text file of raw notes. Omit to read from stdin.")
    parser.add_argument("--employee", "-e", required=True, help="Name of the person being reviewed.")
    parser.add_argument(
        "--language", "-l", choices=["en", "es"], default=None,
        help="Force output language (default: match the input notes).",
    )
    parser.add_argument(
        "--model", "-m", default="claude-sonnet-4-5",
        help="Anthropic model to use (default: claude-sonnet-4-5).",
    )
    parser.add_argument("--output", "-o", help="Write result to this file instead of stdout.")
    args = parser.parse_args()

    if args.input:
        with open(args.input, "r", encoding="utf-8") as f:
            notes = f.read()
    else:
        if sys.stdin.isatty():
            sys.exit("No --input file given and no piped input detected. Provide notes via one of the two.")
        notes = sys.stdin.read()

    if not notes.strip():
        sys.exit("No notes found — the input was empty.")

    system_prompt = SYSTEM_PROMPT
    if args.language == "es":
        system_prompt += "\n\nWrite the entire output in Spanish, regardless of the input language."
    elif args.language == "en":
        system_prompt += "\n\nWrite the entire output in English, regardless of the input language."

    user_prompt = build_user_prompt(args.employee, notes)
    result = call_anthropic(system_prompt, user_prompt, args.model)

    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(result)
        print(f"Written to {args.output}")
    else:
        print(result)


if __name__ == "__main__":
    main()
